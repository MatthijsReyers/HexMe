echo "Installing HexMe version 1.1"
sudo rm /usr/bin/hexme > /dev/null 2>&1
sudo cp hexme /usr/bin
echo "Finished installing..."
